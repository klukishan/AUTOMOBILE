from django.shortcuts import render


# Create your views here.
def customerhomepage(request):
    return render(request, template_name='customerhomepage.html')
