from django.shortcuts import render


# Create your views here.

def homepage(request):
    return render(request, template_name='homepage.html')


def loginpage(request):
    return render(request, template_name='login.html')


def registerpage(request):
    return render(request, template_name='register.html')


def about(request):
    return render(request, template_name='about.html')
