from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
 path('', views.homepage, name='homepage'),
 path('Login/', views.loginpage, name='loginpage'),
 path('Register', views.registerpage, name='registerpage'),
 path('about/', views.about, name='about')
]